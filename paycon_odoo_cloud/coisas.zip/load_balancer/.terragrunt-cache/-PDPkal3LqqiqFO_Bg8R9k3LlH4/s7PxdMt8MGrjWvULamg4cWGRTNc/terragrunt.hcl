# terragrunt.hcl para o ambiente staging, componente load_balancer.
include {
  path = find_in_parent_folders("root.hcl")
}

terraform {
  source = "../../modules/load_balancer"
}

inputs = {
  project_id = "meu-projeto-gcp-staging"
  region     = "us-central1"
}
