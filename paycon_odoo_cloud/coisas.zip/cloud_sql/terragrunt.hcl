# terragrunt.hcl para o ambiente staging, componente cloud_sql.

include {
  path = find_in_parent_folders("root.hcl")
}

terraform {
  source = "../../modules/cloud_sql"
}


inputs = {
  region     = local.region
  project_id = local.project_id
}

