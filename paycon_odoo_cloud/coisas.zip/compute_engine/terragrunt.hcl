# terragrunt.hcl para o ambiente staging, componente compute_engine.
include {
  path = find_in_parent_folders("root.hcl")
}

terraform {
  source = "../../modules/compute_engine"
}

# Exemplo de inputs (ajuste conforme sua necessidade):
inputs = {
  region     = local.region
  project_id = local.project_id
}
